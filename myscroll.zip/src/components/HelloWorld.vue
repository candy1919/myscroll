<template>
  <div class="hello">
    <div>
      <scroll :finishFlag="scrollFlag" @refreshData="refreshData">
        <ul slot="content">
          <li v-for="item in list">{{item}}</li>
        </ul>
      </scroll>
    </div>
  </div>
</template>

<script>
import BScroll from 'better-scroll'
import  scroll  from './scroll'
import { getUser } from "@/util/axios"
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      hit1show:false,
      hit2show:false,
      list:['Core Docs','Core Docs'],
      scrollFlag:true
    }
  },
  components:{
    scroll
  },
  methods:{
    async refreshData () {
      console.log(1)
      var a = await getUser()
      console.log(a.code)
      console.log(2)
      // return Promise.reslove()
    },
    test () {
      this.refreshData()
      console.log("test")
    }
  },
  mounted () {
    this.test()
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
.tag{
  /*position: relative;*/
  /*top:-20px;*/
  padding: 10px 0;
  /*box-sizing: border-box;*/
}
.div{
  height: 100px;
  overflow: hidden;
  border:1px solid red;
}
/*li{
  height: 103px;
}*/
ul {
  list-style-type: none;
  padding: 0;
}

li {
  /*height: 200px;*/
}

a {
  color: #42b983;
}
</style>
